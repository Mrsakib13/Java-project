// Remove the package declaration if the file is not in a subdirectory named 'src'
import java.awt.*;
import java.sql.*;
import javax.swing.*;


public class LibraryGUI extends JFrame {
    private final JTextField titleField = new JTextField(15);
    private final JTextField authorField = new JTextField(15);
    private final JTextField publisherField = new JTextField(15);
    private final JTextField quantityField = new JTextField(5);

    private final JTextField issueBookId = new JTextField(5);
    private final JTextField issueMemberId = new JTextField(5);

    private final JTextField returnTransactionId = new JTextField(5);

    private final JTextArea displayArea = new JTextArea(10, 40);

    public LibraryGUI() {
        setTitle("Library Management System");
        setSize(600, 600);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLayout(new BorderLayout());

        JTabbedPane tabs = new JTabbedPane();

        // Add Book Panel
        JPanel addBookPanel = new JPanel();
        addBookPanel.setLayout(new GridLayout(6, 2));
        addBookPanel.add(new JLabel("Title:"));
        addBookPanel.add(titleField);
        addBookPanel.add(new JLabel("Author:"));
        addBookPanel.add(authorField);
        addBookPanel.add(new JLabel("Publisher:"));
        addBookPanel.add(publisherField);
        addBookPanel.add(new JLabel("Quantity:"));
        addBookPanel.add(quantityField);
        JButton addButton = new JButton("Add Book");
        addButton.addActionListener(e -> addBook());
        addBookPanel.add(addButton);

        // Issue Book Panel
        JPanel issuePanel = new JPanel(new GridLayout(4, 2));
        issuePanel.add(new JLabel("Book ID:"));
        issuePanel.add(issueBookId);
        issuePanel.add(new JLabel("Member ID:"));
        issuePanel.add(issueMemberId);
        JButton issueButton = new JButton("Issue Book");
        issueButton.addActionListener(e -> issueBook());
        issuePanel.add(issueButton);

        // Return Book Panel
        JPanel returnPanel = new JPanel(new GridLayout(2, 2));
        returnPanel.add(new JLabel("Transaction ID:"));
        returnPanel.add(returnTransactionId);
        JButton returnButton = new JButton("Return Book");
        returnButton.addActionListener(e -> returnBook());
        returnPanel.add(returnButton);

        // View Books Panel
        JPanel viewPanel = new JPanel();
        JButton viewButton = new JButton("View Books");
        viewButton.addActionListener(e -> viewBooks());
        displayArea.setEditable(false);
        JScrollPane scrollPane = new JScrollPane(displayArea);
        viewPanel.add(viewButton);
        viewPanel.add(scrollPane);

        // Add tabs
        tabs.addTab("Add Book", addBookPanel);
        tabs.addTab("Issue Book", issuePanel);
        tabs.addTab("Return Book", returnPanel);
        tabs.addTab("View Books", viewPanel);

        add(tabs);
        setVisible(true);
    }

    private void addBook() {
        try (Connection con = DBConnection.getConnection()) {
            String sql = "INSERT INTO books (title, author, publisher, quantity) VALUES (?, ?, ?, ?)";
            PreparedStatement ps = con.prepareStatement(sql);
            ps.setString(1, titleField.getText());
            ps.setString(2, authorField.getText());
            ps.setString(3, publisherField.getText());
            ps.setInt(4, Integer.parseInt(quantityField.getText()));
            ps.executeUpdate();
            JOptionPane.showMessageDialog(this, "Book added successfully!");
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Error: " + e.getMessage());
        }
    }

    private void issueBook() {
        try (Connection con = DBConnection.getConnection()) {
            int bookId = Integer.parseInt(issueBookId.getText());
            int memberId = Integer.parseInt(issueMemberId.getText());

            String checkQty = "SELECT quantity FROM books WHERE book_id = ?";
            PreparedStatement checkStmt = con.prepareStatement(checkQty);
            checkStmt.setInt(1, bookId);
            ResultSet rs = checkStmt.executeQuery();

            if (rs.next() && rs.getInt("quantity") > 0) {
                String issueSql = "INSERT INTO transactions (member_id, book_id, issue_date) VALUES (?, ?, CURDATE())";
                PreparedStatement issueStmt = con.prepareStatement(issueSql);
                issueStmt.setInt(1, memberId);
                issueStmt.setInt(2, bookId);
                issueStmt.executeUpdate();

                String updateQty = "UPDATE books SET quantity = quantity - 1 WHERE book_id = ?";
                PreparedStatement updateStmt = con.prepareStatement(updateQty);
                updateStmt.setInt(1, bookId);
                updateStmt.executeUpdate();

                JOptionPane.showMessageDialog(this, "Book issued successfully!");
            } else {
                JOptionPane.showMessageDialog(this, "Book not available.");
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Error: " + e.getMessage());
        }
    }

    private void returnBook() {
        try (Connection con = DBConnection.getConnection()) {
            int transId = Integer.parseInt(returnTransactionId.getText());

            String getBookId = "SELECT book_id FROM transactions WHERE transaction_id = ?";
            PreparedStatement getStmt = con.prepareStatement(getBookId);
            getStmt.setInt(1, transId);
            ResultSet rs = getStmt.executeQuery();

            if (rs.next()) {
                int bookId = rs.getInt("book_id");

                String returnSql = "UPDATE transactions SET return_date = CURDATE() WHERE transaction_id = ?";
                PreparedStatement returnStmt = con.prepareStatement(returnSql);
                returnStmt.setInt(1, transId);
                returnStmt.executeUpdate();

                String updateQty = "UPDATE books SET quantity = quantity + 1 WHERE book_id = ?";
                PreparedStatement qtyStmt = con.prepareStatement(updateQty);
                qtyStmt.setInt(1, bookId);
                qtyStmt.executeUpdate();

                JOptionPane.showMessageDialog(this, "Book returned successfully!");
            } else {
                JOptionPane.showMessageDialog(this, "Transaction not found.");
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Error: " + e.getMessage());
        }
    }

    private void viewBooks() {
        try (Connection con = DBConnection.getConnection()) {
            String sql = "SELECT * FROM books";
            Statement stmt = con.createStatement();
            ResultSet rs = stmt.executeQuery(sql);

            StringBuilder sb = new StringBuilder("Books in Library:\n");
            while (rs.next()) {
                sb.append("ID: ").append(rs.getInt("book_id"))
                  .append(" | Title: ").append(rs.getString("title"))
                  .append(" | Author: ").append(rs.getString("author"))
                  .append(" | Qty: ").append(rs.getInt("quantity"))
                  .append("\n");
            }
            displayArea.setText(sb.toString());
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Error: " + e.getMessage());
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(LibraryGUI::new);
    }
}
